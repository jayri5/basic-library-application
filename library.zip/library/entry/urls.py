
from django.urls import path

from . import views


urlpatterns = [
    path('', views.index, name='index'),
    #path('add', views.addEntry, name='add'),
    #path('validate', views.validate, name = 'validate'),
    #path('showbooks', views.showbooks, name = 'showbooks'),
    #path('delete', views.delete, name = 'delete'),
    path('findcopies', views.findcopies),
    path('addbook', views.addbook),
    path('viewbook', views.viewbook),
    path('addstudent', views.addstudent),
    path('viewstudent', views.viewstudent),
    path('issuebook', views.issuebook),
    path('deletebook', views.deletebook),
    path('deletestudent', views.deletestudent),
    path('viewissuedbook', views.viewissuedbook),
    #path('sendmail', views.sendmail),
    path('searchbook', views.searchbook),
    path('searchstudent', views.searchstudent),
]
